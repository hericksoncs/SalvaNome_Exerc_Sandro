window.addEventListener("load",function(){
			
			if(localStorage.getItem("name")) {
				listarNome()
			}else{
				qualSeuNome()
			}
		});
		
		function qualSeuNome(){
			var campo = "<input type='text' id='nome' placeholder='Qual � o seu nome'/><button id='bt-salve'>Salvar</button>";
			
			document.body.innerHTML = campo
			document.getElementById("bt-salve").addEventListener("click",salveName)
		}
		
		
		function listarNome(){
			var mensagem = "<h1> Ol� " + localStorage.getItem("name") + "</h1><button id='bt-remove'>Remover</button>";
			
			document.body.innerHTML = mensagem;
			document.getElementById("bt-remove").addEventListener("click",removerName)
		}
		
		function removerName(){
			if(localStorage.getItem("name")){
				localStorage.removeItem("name");
				qualSeuNome()
			}	
		}
		
		function salveName(){
			var nome = document.getElementById("nome").value;
			localStorage.setItem("name", nome) 
			listarNome();
		}